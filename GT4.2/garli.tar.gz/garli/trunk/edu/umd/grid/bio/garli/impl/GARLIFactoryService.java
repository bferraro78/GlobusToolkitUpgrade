package edu.umd.grid.bio.garli.impl;

import edu.umd.umiacs.cummings.GSBL.GSBLFactoryService;

public class GARLIFactoryService extends GSBLFactoryService {
	
	// Despite the fact that this class is empty, it seems necessary to preserve the one-to-one factory/instance service model.
	
}
