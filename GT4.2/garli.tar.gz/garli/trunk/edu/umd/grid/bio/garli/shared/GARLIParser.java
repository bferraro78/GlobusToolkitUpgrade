package edu.umd.grid.bio.garli.shared;

import java.io.*;
import java.util.*;

import java.lang.Runtime;

// For logging
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.Properties;

// stub classes
import edu.umd.grid.bio.garli.stubs.GARLIService.GARLIArguments;

/**
 * Class that parses the garli.conf file to determine which files will be
 * input/output.
 *
 * @author Matthew Conte (conte@umiacs.umd.edu)
 * @author Adam Bazinet (pknut777@umiacs.umd.edu)
 */

public class GARLIParser {

    /**
     * Logger.
     */
    static Log log = LogFactory.getLog(GARLIParser.class.getName());

    /**
     * The filename of the config file to parse.
     */
    protected String configFileName;
    
    /* 
     * Where to look for files.
     */
    String myWorkingDir;
    
    /**
     * The files needed for input.
     */
    Vector inputFiles;
    
    /**
     * The files produced as output.
     */
    Vector outputFiles;
	
    /**
     * String buffer for storing the config file.
     */
    protected StringBuffer configBuffer;

    /**
     * The minimum amount of memory that should be specified
     */
    protected String min_mem = null;

    /**
     * The maximum amount of memory that should be specified
     */
    protected String max_mem = null;

    /**
     * The actual amount of memory GARLI will use
     */
    protected String actual_mem = null;

    /**
     * The number of unique patterns in the data set
     */
    protected String unique_patterns = null;

    /**
     * The number of taxa in the data set
     */
    protected String num_taxa = null;

    /**
     * The amount of memory currently specified
     */
    protected String avail_mem = null;

    /**
     * The maximum amount of memory we are currently allowing (4G)
     */
    protected int max_sys_mem = 13000;

    /**
     * Memory "tipping point" (1G)
     */
    protected int med_sys_mem = 1024;

    /**
     * Number of search replicates (in GARLI config, "searchreps")
     */
    protected Integer searchreps = new Integer(1);

    /**
     * Number of bootstrap replicates (in GARLI config, "bootstrapreps")
     */
    protected Integer bootstrapreplicates = new Integer(0);

    /**
     * Whether or not the data file is valid
     */
    protected boolean valid_dataf = false;

    /**
     * GARLIArguments "Bean"
     */
    protected GARLIArguments argBean = null;

    /**
     * The GLOBUS_LOCATION.
     */
    protected static String globusLocation = "";

    /**
     * Whether or not we built the config file ourselves.
     */
    protected boolean built_config = false;

    /**
     * Whether or not we validated the input files.
     */
    protected boolean validated_input = false;


    /**
     * Constructor
     * @param myBean       argument bean
     * @param workingDir   the working directory to use
     * @param buildConfig  build a config file from command line arguments
     * @param doValidate   validate the data file; get memory to be used
     * @param doParse      parse the config file (true/false)
     */
    public GARLIParser(GARLIArguments myBean, String workingDir, boolean buildConfig, boolean doValidate, boolean doParse) throws Exception {

	// determine the globus location
	Properties env = new Properties();
	try {        	
	    env.load(Runtime.getRuntime().exec("env").getInputStream());
	} catch(Exception e) {
	    log.error("Exception: " + e);
	}
	globusLocation = (String) env.get("GLOBUS_LOCATION");

	// get shared files
	String[] tempSharedFiles = myBean.getSharedFiles();
	if(tempSharedFiles == null) {
	    tempSharedFiles = new String[0];
	}
	ArrayList<String> sharedFiles = new ArrayList<String>(Arrays.asList(tempSharedFiles));

	// get per-job files
	String[] tempPerJobFiles = myBean.getPerJobFiles();

	if(tempPerJobFiles == null) {
	    tempPerJobFiles = new String[0];
	}
	ArrayList<String[]> perJobFiles = new ArrayList<String[]>();
	for(int i = 0; i < tempPerJobFiles.length; i++) {
	    String filenames = tempPerJobFiles[i];
	    String[] chunks = filenames.split(":");
	    perJobFiles.add(chunks);
	}

	argBean = myBean;

	this.inputFiles = new Vector();
	this.outputFiles = new Vector();

	if(buildConfig == false) { // config file already exists

	    // determine if path-to-config-file is a directory
	    File dir = new File(workingDir + myBean.getConfigFile());
	    if(!dir.exists()) {
		String justTheName = dir.getName();
		// hack: (this whole service should be rewritten anyway)
		// assumption: this is on the server side, and we need to find a garli.conf that now exists in the cache
		//String tempWorkingDir = workingDir.substring(0, workingDir.length()-1);
		String baseDir = workingDir.substring(0, workingDir.lastIndexOf("/"));
		baseDir = baseDir.substring(0, baseDir.lastIndexOf("/"));
		String cacheDir = baseDir + "/cache/";
		boolean foundConfigFile = false;
		
		for(String sharedFile : sharedFiles) {
		    if(sharedFile.indexOf(justTheName) != -1) { // we've got a match
			this.configFileName = cacheDir + sharedFile;
			foundConfigFile = true;
			break;
		    }
		}
		if(foundConfigFile == false) { // check per-job files
		    for(String[] perJobArray : perJobFiles) {
			for(int i = 0; i < perJobArray.length; i++) {
			    String perJobFile = perJobArray[i];
			    if(perJobFile.indexOf(justTheName) != -1) { // we've got a match
				this.configFileName = cacheDir + perJobFile;
				foundConfigFile = true;
				break;
			    }
			}
			if(foundConfigFile == true) {
			    break;
			}
		    }
		}
		
		if(foundConfigFile == false) {
		    log.error("ERROR: no conf file found when searching through shared/per-job files!");
		    this.configFileName = "";
		}
		
		log.debug("configFileName is: " + configFileName);
	    } else if(dir.isDirectory()) { // we need to grab a sample garli.conf file out of here to use for parsing
		String[] filenames = dir.list();
		this.configFileName = workingDir + myBean.getConfigFile() + "/" + filenames[0];
	    } else {
		this.configFileName = workingDir + myBean.getConfigFile();
		// add to input files (shared files, really) here
		inputFiles.add(configFileName);
	    }
	}

	configBuffer = new StringBuffer();
	myWorkingDir = workingDir;

	if(buildConfig) {
	    this.built_config = true;
	    buildConfig();
	}

	if(doValidate) {
	    this.validated_input = true;
	    validate();
	}
	
	if(doParse) {
	    parse();
	}
    }

    /**
     * Build a GARLI configuration file using a combination of defaults and CL arguments.  Write it out to the working directory and call it garli.conf.
     */
    protected void buildConfig() throws Exception {
	configBuffer.append("[general]\n");

	if(argBean.getDatafname() == null) { // this must be specified!
	    log.error("Please specify a data file with the --datafname argument!");
	    System.exit(1);
	} else {
	    configBuffer.append("datafname = " + argBean.getDatafname() + "\n");
	}

	if(argBean.getConstraintfile() != null) {
	    configBuffer.append("constraintfile = " + argBean.getConstraintfile() + "\n");
	}

	if(argBean.getStreefname() != null) {
	    if(argBean.getStreefname().equalsIgnoreCase("file")) {
		if(argBean.getStreefname_userdata() != null) {
		    configBuffer.append("streefname = " + argBean.getStreefname_userdata() + "\n");
		} else {
		    log.error("Please specify a value for the --streefname_userdata argument!");
		    System.exit(1);
		}
	    } else {
		configBuffer.append("streefname = " + argBean.getStreefname() + "\n");
	    }
	} else {
	    configBuffer.append("streefname = random\n");
	}

	if(argBean.getAttachmentspertaxon() != null) {
	    configBuffer.append("attachmentspertaxon = " + argBean.getAttachmentspertaxon() + "\n");
	} else {
	    configBuffer.append("attachmentspertaxon = 50\n");
	}

	if(argBean.getOfprefix() != null) {
	    configBuffer.append("ofprefix = " + argBean.getOfprefix() + "\n");
	} else {
	    configBuffer.append("ofprefix = garli\n");
	}

	configBuffer.append("randseed = -1\n");

	configBuffer.append("availablememory = 512\n");

	configBuffer.append("logevery = 100000\n");
	configBuffer.append("saveevery = 100000\n");

	if(argBean.getRefinestart() != null) {
	    if((argBean.getRefinestart()).booleanValue() == true) {
		configBuffer.append("refinestart = 1\n");
	    } else {
		configBuffer.append("refinestart = 0\n");
	    }
	} else {
	    configBuffer.append("refinestart = 1\n");
	}
		
	configBuffer.append("outputeachbettertopology = 0\n");
	configBuffer.append("outputcurrentbesttopology = 0\n");
	configBuffer.append("enforcetermconditions = 1\n");
	configBuffer.append("genthreshfortopoterm = 5000\n");
	configBuffer.append("scorethreshforterm = 0.05\n");
	configBuffer.append("significanttopochange = 0.01\n");

	if(argBean.getOutputphyliptree() != null) {
	    if((argBean.getOutputphyliptree()).booleanValue() == true) {
		configBuffer.append("outputphyliptree = 1\n");
	    } else {
		configBuffer.append("outputphyliptree = 0\n");
	    }
	} else {
	    configBuffer.append("outputphyliptree = 0\n");
	}

	configBuffer.append("outputmostlyuselessfiles = 0\n");
	configBuffer.append("writecheckpoints = 0\n");
	configBuffer.append("restart = 0\n");
	
	if(argBean.getOutgroup() != null) {
	    configBuffer.append("outgroup = " + argBean.getOutgroup() + "\n");
	}

	if(argBean.getOutputsitelikelihoods() != null) {
	    if((argBean.getOutputsitelikelihoods()).booleanValue() == true) {
		configBuffer.append("outputsitelikelihoods = 1\n");
	    } else {
		configBuffer.append("outputsitelikelihoods = 0\n");
	    }
	} else {
	    configBuffer.append("outputsitelikelihoods = 0\n");
	}

	if(argBean.getCollapsebranches() != null) {
	    if((argBean.getCollapsebranches()).booleanValue() == true) {
		configBuffer.append("collapsebranches = 1\n");
	    } else {
		configBuffer.append("collapsebranches = 0\n");
	    }
	} else {
	    configBuffer.append("collapsebranches = 1\n");
	}

	configBuffer.append("searchreps = 1\n\n");

	if(argBean.getDatatype() != null) {
	    configBuffer.append("datatype = " + argBean.getDatatype() + "\n");
	} else {
	    configBuffer.append("datatype = nucleotide\n");
	}
	
	if(argBean.getRatematrix() != null) {
	    configBuffer.append("ratematrix = " + argBean.getRatematrix() + "\n");
	} else {
	    configBuffer.append("ratematrix = 6rate\n");
	}

	if(argBean.getStatefrequencies() != null) {
	    configBuffer.append("statefrequencies = " + argBean.getStatefrequencies() + "\n");
	} else {
	    configBuffer.append("statefrequencies = estimate\n");
	}

	if(argBean.getRatehetmodel() != null) {
	    configBuffer.append("ratehetmodel = " + argBean.getRatehetmodel() + "\n");
	} else {
	    configBuffer.append("ratehetmodel = gamma\n");
	}

	if(argBean.getRatehetmodel() != null) {
	    if((argBean.getRatehetmodel()).equals("none")) {
		configBuffer.append("numratecats = 1\n");
	    } else {
		if(argBean.getNumratecats() != null) {
		    configBuffer.append("numratecats = " + argBean.getNumratecats() + "\n");
		} else {
		    configBuffer.append("numratecats = 4\n");
		}
	    }
	} else {
	    if(argBean.getNumratecats() != null) {
		configBuffer.append("numratecats = " + argBean.getNumratecats() + "\n");
	    } else {
		configBuffer.append("numratecats = 4\n");
	    }
	}

	if(argBean.getInvariantsites() != null) {
	    configBuffer.append("invariantsites = " + argBean.getInvariantsites() + "\n");
	} else {
	    configBuffer.append("invariantsites = estimate\n\n");
	}

	configBuffer.append("[master]\n");

	if(argBean.getNindivs() != null) {
	    configBuffer.append("nindivs = " + argBean.getNindivs() + "\n");
	} else {
	    configBuffer.append("nindivs = 4\n");
	}

	configBuffer.append("holdover = 1\n");

	if(argBean.getSelectionintensity() != null) {
	    configBuffer.append("selectionintensity = " + argBean.getSelectionintensity() + "\n");
	} else {
	    configBuffer.append("selectionintensity = 0.5\n");
	}

	configBuffer.append("holdoverpenalty = 0\n");
	configBuffer.append("stopgen = 5000000\n");
	configBuffer.append("stoptime = 5000000\n");

	if(argBean.getStartoptprec() != null) {
	    configBuffer.append("startoptprec = " + argBean.getStartoptprec() + "\n");
	} else {
	    configBuffer.append("startoptprec = 0.5\n");
	}

	if(argBean.getMinoptprec() != null) {
	    configBuffer.append("minoptprec = " + argBean.getMinoptprec() + "\n");
	} else {
	    configBuffer.append("minoptprec = 0.01\n");
	}

	if(argBean.getNumberofprecreductions() != null) {
	    configBuffer.append("numberofprecreductions = " + argBean.getNumberofprecreductions() + "\n");
	} else {
	    configBuffer.append("numberofprecreductions = 10\n");
	}

	if(argBean.getTreerejectionthreshold() != null) {
	    configBuffer.append("treerejectionthreshold = " + argBean.getTreerejectionthreshold() + "\n");
	} else {
	    configBuffer.append("treerejectionthreshold = 50.0\n");
	}

	if(argBean.getTopoweight() != null) {
	    configBuffer.append("topoweight = " + argBean.getTopoweight() + "\n");
	} else {
	    configBuffer.append("topoweight = 1.0\n");
	}

	if(argBean.getModweight() != null) {
	    configBuffer.append("modweight = " + argBean.getModweight() + "\n");
	} else {
	    configBuffer.append("modweight = 0.05\n");
	}

	if(argBean.getBrlenweight() != null) {
	    configBuffer.append("brlenweight = " + argBean.getBrlenweight() + "\n");
	} else {
	    configBuffer.append("brlenweight = 0.2\n");
	}

	if(argBean.getRandnniweight() != null) {
	    configBuffer.append("randnniweight = " + argBean.getRandnniweight() + "\n");
	} else {
	    configBuffer.append("randnniweight = 0.1\n");
	}

	if(argBean.getRandsprweight() != null) {
	    configBuffer.append("randsprweight = " + argBean.getRandsprweight() + "\n");
	} else {
	    configBuffer.append("randsprweight = 0.3\n");
	}

	if(argBean.getLimsprweight() != null) {
	    configBuffer.append("limsprweight = " + argBean.getLimsprweight() + "\n");
	} else {
	    configBuffer.append("limsprweight = 0.6\n");
	}

	configBuffer.append("intervallength = 100\n");
	configBuffer.append("intervalstostore = 5\n");

	if(argBean.getLimsprrange() != null) {
	    configBuffer.append("limsprrange = " + argBean.getLimsprrange() + "\n");
	} else {
	    configBuffer.append("limsprrange = 6\n");
	}

	if(argBean.getMeanbrlenmuts() != null) {
	    configBuffer.append("meanbrlenmuts = " + argBean.getMeanbrlenmuts() + "\n");
	} else {
	    configBuffer.append("meanbrlenmuts = 5\n");
	}

	if(argBean.getGammashapebrlen() != null) {
	    configBuffer.append("gammashapebrlen = " + argBean.getGammashapebrlen() + "\n");
	} else {
	    configBuffer.append("gammashapebrlen = 1000\n");
	}

	if(argBean.getGammashapemodel() != null) {
	    configBuffer.append("gammashapemodel = " + argBean.getGammashapemodel() + "\n");
	} else {
	    configBuffer.append("gammashapemodel = 1000\n");
	}

	if(argBean.getUniqueswapbias() != null) {
	    configBuffer.append("uniqueswapbias = " + argBean.getUniqueswapbias() + "\n");
	} else {
	    configBuffer.append("uniqueswapbias = 0.1\n");
	}

	if(argBean.getDistanceswapbias() != null) {
	    configBuffer.append("distanceswapbias = " + argBean.getDistanceswapbias() + "\n");
	} else {
	    configBuffer.append("distanceswapbias = 1.0\n\n");
	}

	if(argBean.getAnalysistype() != null) {
	    if(argBean.getAnalysistype().equalsIgnoreCase("bootstrap")) {
		configBuffer.append("bootstrapreps = 1\n");
	    } else {
		configBuffer.append("bootstrapreps = 0\n");
	    }
	} else {
	    configBuffer.append("bootstrapreps = 0\n");
	}

	if(argBean.getResampleproportion() != null) {
	    configBuffer.append("resampleproportion = " + argBean.getResampleproportion() + "\n");
	} else {
	    configBuffer.append("resampleproportion = 1.0\n");
	}

	if(argBean.getInferinternalstateprobs() != null) {
	    if((argBean.getInferinternalstateprobs()).booleanValue() == true) {
		configBuffer.append("inferinternalstateprobs = 1\n");
	    } else {
		configBuffer.append("inferinternalstateprobs = 0\n");
	    }
	} else {
	    configBuffer.append("inferinternalstateprobs = 0\n");
	}

	argBean.setConfigFile("garli.conf");
	this.configFileName = "garli.conf";
	// add to input files (shared files, really) here
	inputFiles.add(configFileName);
	
	writeConfig();
	
    }

    /**
     * Write out config file to disk.
     */
    protected void writeConfig() throws Exception {
	// write out the config file to the current working directory
	BufferedWriter writer = new BufferedWriter(new FileWriter(this.configFileName));
	writer.write(configBuffer.toString());
	writer.close();
    }

    /**
     * Validate a GARLI data file by executing Garli-1.0 in "validate" mode.  Also parse out memory usage information, number of unique patterns, and number of taxa.
     */
    protected void validate() throws Exception {
	Runtime r = Runtime.getRuntime();
	String exec_me = globusLocation + "/validate_garli_conf.pl " + this.configFileName;
	Process proc = r.exec(exec_me);
	String line = null;
	String outputString = null;
	InputStream stdout = proc.getInputStream();
	InputStreamReader isr = new InputStreamReader(stdout);
	BufferedReader br = new BufferedReader(isr);
	while((line = br.readLine()) != null) {
	    outputString = line;
	}
	br.close();

	// assign min_mem, max_mem, unique_patterns, num_taxa, actual_mem, and valid_dataf
	String[] chunks = outputString.split(" ", 6);
	this.min_mem = chunks[0];
	this.max_mem = chunks[1];
	this.unique_patterns = chunks[2];
	this.num_taxa = chunks[3];
	this.actual_mem = chunks[4];
	this.valid_dataf = (new Boolean(chunks[5])).booleanValue();

	if(this.valid_dataf == false) {
	    log.error("There was a problem validating the input data.  " + outputString + "  Exiting...");
	    System.exit(1);
	}

	try {
	    Integer.parseInt(this.min_mem);
	} catch(NumberFormatException e) {
	    log.error("Could not ascertain minimum memory requirement!  Exiting...");
	    System.exit(1);
	}
	    
	if(this.min_mem.equals("0")) {
	    log.error("Could not ascertain minimum memory requirement!  Exiting...");
	    System.exit(1);
	}

	try {
	    Integer.parseInt(this.max_mem);
	} catch(NumberFormatException e) {
	    log.error("Could not ascertain maximum memory requirement!  Exiting...");
	    System.exit(1);
	}

	if(this.max_mem.equals("0")) {
	    log.error("Could not ascertain maximum memory requirement!  Exiting...");
	    System.exit(1);
	}

	try {
            Integer.parseInt(this.actual_mem);
        } catch(NumberFormatException e) {
            log.error("Could not ascertain actual memory requirement!  Exiting...");
            System.exit(1);
        }

        if(this.actual_mem.equals("0")) {
            log.error("Could not ascertain actual memory requirement!  Exiting...");
            System.exit(1);
        }

	try {
            Integer.parseInt(this.unique_patterns);
        } catch(NumberFormatException e) {
            log.error("Could not ascertain number of unique patterns!  Exiting...");
            System.exit(1);
        }

        if(this.unique_patterns.equals("0")) {
            log.error("Could not ascertain number of unique patterns!  Exiting...");
            System.exit(1);
        }

	try {
            Integer.parseInt(this.num_taxa);
        } catch(NumberFormatException e) {
            log.error("Could not ascertain number of taxa!  Exiting...");
            System.exit(1);
        }

        if(this.num_taxa.equals("0")) {
            log.error("Could not ascertain number of taxa!  Exiting...");
            System.exit(1);
        }
    }
    
    /**
     * Parse the config file, setting the inputFiles and outputFiles vectors
     * as we go.
     */
    protected void parse() throws Exception {
	       
	// The ofprefix variable in the config file will determine the first 
	// portion of a lot of the output files.
	String ofprefix = "";
	String datatype = "";
	boolean outputphyliptree = false;
	boolean outputeachbettertopology = false;
	boolean outputmostlyuselessfiles = false;
	boolean outputsitelikes = false;
	boolean bootstrapreps = false;
	boolean inferinternalstateprobs = false;
	String constraintfile = ""; // if this is set to something other than none, add it to the inputFiles vector
	boolean writecheckpoints = false; // not supporting at the moment.
	boolean restart = false; // not supporting at the moment
	boolean ratehetmodel = false; // none, gamma, gammafixed. false for none, true for gamma or gammafixed
	String numratecats = ""; // 1 to 20, must be set to 1 if ratehetmodel is set to none
	boolean uniqueswapbias = false; // 0.01 to 1.0 (If < 1.0 and outputmostlyuseless files is on then swap.log is output)
	                                // true if < 1.0, false if = 1.0
	String ratematrix = ""; // if set to "estimate", AArmatrix.dat is output
	Double usb;
	Integer logevery = new Integer(1);
	Integer saveevery = new Integer(1);

	try {
	    BufferedReader instream = new BufferedReader(new FileReader(configFileName));
	    String line;
	    
	    while ( (line = instream.readLine()) != null) {

		String [] splitLine = line.split("=");

		for (int i = 0; i < splitLine.length; i++) {
		    splitLine[i] = splitLine[i].trim();
		}
		
		String garliVar = splitLine[0];
		String garliVarVal = "";
		if (splitLine.length > 1) {
		    garliVarVal = splitLine[1];
		}
				
		if (garliVar.equalsIgnoreCase("DATAFNAME")) {
		    // Check to see if the datafile specified in the config file is a path; we are no longer allowing paths!
		    String fullDataFileName = garliVarVal;
		    String [] splitPath = fullDataFileName.split("/");

		    if(splitPath.length > 1) {
			log.error("We are not currently supporting paths to data files; please fix your garli.conf file and try again.");
			System.exit(1);
		    }

		    // Check to see if the datafile specified exists; only perform this action on the client
		    File testDataFile = new File(fullDataFileName);
		    if(myWorkingDir.equals("")) {
			if(!testDataFile.exists()) {
			    log.error("Data file " + testDataFile.toString() + " does not exist!");
			    System.exit(1);
			}
		    }
		    
		    // add the data file
		    inputFiles.add(fullDataFileName);
		}

		if (garliVar.equalsIgnoreCase("RANDSEED")) {
		    // in the latest version of GARLI, 0 is not allowed
		    if(garliVarVal.equals("0")) {
			log.error("randseed = 0 is not allowed!\nModify your garli.conf file and try again!");
			System.exit(1);
		    }
		}

		if (garliVar.equalsIgnoreCase("datatype")) {
		    datatype = garliVarVal;
		    if(argBean.getDatatype() == null) {
			argBean.setDatatype(garliVarVal);
		    }
		}
		if (garliVar.equalsIgnoreCase("statefrequencies")) {
		    if(argBean.getStatefrequencies() == null) {
			argBean.setStatefrequencies(garliVarVal);
		    }
		}
		if (garliVar.equalsIgnoreCase("invariantsites")) {
		    if(argBean.getInvariantsites() == null) {
			argBean.setInvariantsites(garliVarVal);
		    }
		}
		if (garliVar.equalsIgnoreCase("OFPREFIX")) {
		    ofprefix = garliVarVal;
		}
		if (garliVar.equalsIgnoreCase("OUTPUTPHYLIPTREE") && garliVarVal.equals("1")) {
		    outputphyliptree = true;
		}
		if (garliVar.equalsIgnoreCase("outputeachbettertopology") && garliVarVal.equals("1")) {
		    outputeachbettertopology = true;
		}
		if (garliVar.equalsIgnoreCase("outputmostlyuselessfiles") && garliVarVal.equals("1")) {
		    outputmostlyuselessfiles = true;
		}
		if (garliVar.equalsIgnoreCase("outputsitelikelihoods") && garliVarVal.equals("1")) {
		    outputsitelikes = true;
		}
		if (garliVar.equalsIgnoreCase("bootstrapreps") && !garliVarVal.equals("0")) {
		    bootstrapreplicates = new Integer(garliVarVal);
		    bootstrapreps = true;
		}
		if (garliVar.equalsIgnoreCase("inferinternalstateprobs") && garliVarVal.equals("1")) {
		    inferinternalstateprobs = true;
		}
		if (garliVar.equalsIgnoreCase("availablememory")) {

		    int specified_mem = (new Integer(garliVarVal)).intValue();

		    if(this.validated_input) {
			int min_mem_int = (new Integer(min_mem)).intValue();
			int max_mem_int = (new Integer(max_mem)).intValue();

			if(built_config) { // if we built the config file, we must set the memory ourselves
			    // determine how much memory to use
			    if(min_mem_int > max_sys_mem) {
				log.error("Data file requires greater than " + (new Integer(max_sys_mem)).toString() + "M of memory and cannot be processed.\n");
				System.exit(1);
			    }
			    if(min_mem_int > med_sys_mem) { // use the minimum amount of memory required
				log.debug("setting avail_mem to: " + min_mem);
				avail_mem = min_mem;
			    } else if(max_mem_int > med_sys_mem) {
				log.debug("setting avail_mem to: " + (new Integer(med_sys_mem)).toString());
				avail_mem = (new Integer(med_sys_mem)).toString();
			    } else {
				log.debug("setting avail_mem to: " + max_mem);
				avail_mem = max_mem;
			    }
			    
			    int avail_begin_index = configBuffer.indexOf("availablememory");
			    int avail_end_index = configBuffer.indexOf("\n", avail_begin_index);
			    configBuffer = configBuffer.replace(avail_begin_index, avail_end_index, "availablememory = " + avail_mem + "\n");
			    
			    // write config out again
			    writeConfig();
			} else { // verify the memory specified is within legal bounds
			    if(specified_mem > max_sys_mem) {
				log.error("Config file specifies greater than " + (new Integer(max_sys_mem)).toString() + "M of memory and cannot be processed.\n");
				System.exit(1);
			    } else if(specified_mem < min_mem_int) {
				log.error("Config file specifies less than the minimum memory requirement of " + min_mem + "M of memory and cannot be processed.\n");
				System.exit(1);
			    } else {
				log.debug("setting avail_mem to: " + garliVarVal);
				avail_mem = garliVarVal;
			    }
			}
		    } else {
			log.debug("setting avail_mem to: " + garliVarVal);
			avail_mem = garliVarVal;
		    }
		}

		// v0.951 settings
                if (garliVar.equalsIgnoreCase("streefname") && !garliVarVal.equals("random") && !garliVarVal.equals("stepwise")) {
		    // Check to see if the treefile specified in the config file is a path; we are no longer allowing paths!
		    String fullTreeFileName = garliVarVal;
		    String [] splitPath = fullTreeFileName.split("/");

		    if(splitPath.length > 1) {
			log.error("We are not currently supporting paths to tree files; please fix your garli.conf file and try again.");
			System.exit(1);
		    }


		    // Check to see if the treefile specified exists; only perform this action on the client
		    File testTreeFile = new File(fullTreeFileName);
		    if(myWorkingDir.equals("")) {
			if(!testTreeFile.exists()) {
			    log.error("Tree file " + testTreeFile.toString() + " does not exist!");
			    System.exit(1);
			}
		    }
                    inputFiles.add(fullTreeFileName);
		}
		if (garliVar.equalsIgnoreCase("constraintfile") && !garliVarVal.equals("none")) {
		    // Check to see if the constraint file specified in the config file is a path; we are no longer allowing paths!
		    String fullConstraintFileName = garliVarVal;
		    String [] splitPath = fullConstraintFileName.split("/");

		    if(splitPath.length > 1) {
			log.error("We are not currently supporting paths to constraint files; please fix your garli.conf file and try again.");
			System.exit(1);
		    }


		    // Check to see if the constraint file specified exists; only perform this action on the client
		    File testConstraintFile = new File(fullConstraintFileName);
		    if(myWorkingDir.equals("")) {
			if(!testConstraintFile.exists()) {
			    log.error("Constraint file " + testConstraintFile.toString() + " does not exist!");
			    System.exit(1);
			}
		    }
		    inputFiles.add(fullConstraintFileName);
		}
		if (garliVar.equalsIgnoreCase("writecheckpoints") && garliVarVal.equals("1")) {
		    writecheckpoints = true;
		}
		if (garliVar.equalsIgnoreCase("restart") && garliVarVal.equals("1")) {
		    restart = true;
		}
		if (garliVar.equalsIgnoreCase("ratehetmodel")) {
			if(argBean.getRatehetmodel() == null) {
			    argBean.setRatehetmodel(garliVarVal);
			}
			if(!garliVarVal.equals("none")) {
			    ratehetmodel = true;
			}
		}
		if (garliVar.equalsIgnoreCase("numratecats")) {
		    if(argBean.getNumratecats() == null) {
			argBean.setNumratecats(Integer.valueOf(garliVarVal));
		    }
		    numratecats = garliVarVal;
		}
		if (garliVar.equalsIgnoreCase("uniqueswapbias")) {
		    usb = new Double (garliVarVal);
		    if (usb.doubleValue() < 1.000000) {
			uniqueswapbias = true;
		    }
		}
		if (garliVar.equalsIgnoreCase("ratematrix")) {
			if(argBean.getRatematrix() == null) {
			    argBean.setRatematrix(garliVarVal);
			}
			if(garliVarVal.equalsIgnoreCase("estimate")) {
			    ratematrix = "estimate";
			}
		}
		if (garliVar.equalsIgnoreCase("searchreps")) {
		    searchreps = new Integer (garliVarVal);
		    if(searchreps.intValue() < 1) {
			log.error("searchreps must be >= 1!  fix your garli.conf file and try again.\n");
			System.exit(1);
		    }
		}
		if (garliVar.equalsIgnoreCase("logevery")) {
		    logevery = new Integer (garliVarVal);
		    //if(logevery.intValue() < 10000) {
		    //log.error("logevery must be >= 10000!  fix your garli.conf file and try again.\n");
		    //System.exit(1);
		    //}
		}
		if (garliVar.equalsIgnoreCase("saveevery")) {
		    saveevery = new Integer (garliVarVal);
		    //if(saveevery.intValue() < 10000) {
		    //log.error("saveevery must be >= 10000!  fix your garli.conf file and try again.\n");
		    //System.exit(1);
		    //}
		}		    
	    }
	} catch (FileNotFoundException fe) {
	    log.error("1)datafname specified does not exist or");
	    log.error("2)configFile: " + configFileName + " is not found\n" + fe);
	    throw fe;
	} catch (IOException ie) {
	    log.error("IOException reading configFile " + configFileName + ": " + ie);
	}

	// Now that we definitely have the 'ofprefix', add the output files

	// In v0.951 no ofprefix.best.tre file is output for bootstrap runs
	if(bootstrapreps) {
	    outputFiles.add(ofprefix + ".boot.tre");
	    log.debug("bootstrap only");
	} else {
	    outputFiles.add(ofprefix + ".best.tre");
	    log.debug("no bootstrap");
	}
	
	if(searchreps.intValue() > 1) {
	    if(!bootstrapreps) {
		outputFiles.add(ofprefix + ".best.all.tre");
		if(outputphyliptree) {
		    outputFiles.add(ofprefix + ".best.all.phy");
		}
	    }
	}

	outputFiles.add(ofprefix + ".screen.log"); // v0.951
	outputFiles.add(ofprefix + ".log00.log"); // why wasn't 

	if(outputphyliptree && !bootstrapreps) {
	    outputFiles.add(ofprefix + ".best.phy");
	} else if(outputphyliptree && bootstrapreps) {
	    outputFiles.add(ofprefix + ".boot.phy");
	}

	if(outputeachbettertopology && !bootstrapreps) {
	    if(searchreps.intValue() == 1) {
		outputFiles.add(ofprefix + ".treelog00.tre"); // changed from .log to .tre in 0.96b6.r226
		                                              // also, treelogs turned off for bootstrap runs in same
	    } else {
		for(int i = 1; i <= searchreps.intValue(); i++) {
		    outputFiles.add(ofprefix + ".rep" + i + ".treelog00.tre");
		}
	    }	    
	}
	if(outputmostlyuselessfiles) {
	    outputFiles.add(ofprefix + ".fate00.log");
	    outputFiles.add(ofprefix + ".problog00.log");
	}

	if(outputsitelikes) {
	    outputFiles.add(ofprefix + ".sitelikes.log");
	}

	if(inferinternalstateprobs) {
	    outputFiles.add(ofprefix + ".internalstates.log");
	}

	if(ratematrix.equals("estimate") && (datatype.equalsIgnoreCase("aminoacid") || datatype.equalsIgnoreCase("codon-aminoacid")) && !bootstrapreps) {
	    outputFiles.add(ofprefix + ".AArmatrix.dat");
	}

	// v0.951
	if (writecheckpoints || restart) {
	    log.error("We are not currently supporting GARLI checkpointing, please fix your garli.conf file.");
	    throw new Exception("We are not currently supporting GARLI checkpointing, please fix your garli.conf file and check back in the future (10-6-06)");
	}
	if (!numratecats.equals("1") && !ratehetmodel) {
	    log.error("numratecats must be set to 1 (not " + numratecats + " or anything else above 1) if ratehetmodel is set to none, please fix your garli.conf file.");
	    throw new Exception("numratecats must be set to 1 (not " + numratecats + " or anything else above 1) if ratehetmodel is set to none, please fix your garli.conf file.");
	}
	if (uniqueswapbias && outputmostlyuselessfiles) {
	    outputFiles.add(ofprefix + ".swaplog00.log");
	}
    }


    /**
     * Overwrites the input file with a modified version.
     * Should only be used on the server side!
     *
     * Currently this method doesn't not support rewriting all the config files in a hetero job batch, but it should be changed to!
     */
    public void rewriteConfigFile() throws FileNotFoundException, IOException
    {
        try {
            //log.debug("Writing temp input file: " + filename + "_deleteme");

            BufferedWriter writer = new BufferedWriter(new FileWriter(configFileName + "_deleteme"));
	    writer.write(configBuffer.toString());
            writer.close();

            //log.debug("About to move temp file..");

            // Overwrite input file with modified version
            File newinput = new File(configFileName + "_deleteme");
            boolean didRename = false;
            didRename = newinput.renameTo(new File(configFileName));
            if (didRename == false) {
                log.error("Could not overwrite config file!");
                throw new FileNotFoundException("Could not find file: " + configFileName + "_deleteme");
            }

        } catch (FileNotFoundException fe) {
            log.error("Config file not found while writing new config file: " + fe);
            throw fe;
        } catch (IOException ie) {
            log.error("IOException while writing new config file: " + ie);
            throw ie;
        }
    }

    
    /**
     * Returns a String array containing the input filenames
     */
    public Collection getInputFiles() {
	ArrayList<String> inFiles = new ArrayList<String>();
	for (int i = 0; i < inputFiles.size(); i++) {
	    inFiles.add((String)inputFiles.elementAt(i));
	}
        return inFiles;
    }

    /**
     * Returns a String array containing the output filenames
     */
    public String[] getOutputFiles() {
	String [] outFiles = new String[outputFiles.size()];
	for (int i = 0; i < outputFiles.size(); i++) {
	    outFiles[i] = new File((String) outputFiles.elementAt(i)).getName();
	}
        return outFiles;
    }

    
    public String getAvailMem() {
	return avail_mem;
    }

    public void setAvailMem(String mem) {
	avail_mem = mem;
    }

    public String getActualMem() {
	return actual_mem;
    }

    public void setActualMem(String mem) {
	actual_mem = mem;
    }

    public String getUniquePatterns() {
	return unique_patterns;
    }

    public void setUniquePatterns(String unique_pats) {
	unique_patterns = unique_pats;
    }

    public String getNumTaxa() {
	return num_taxa;
    }

    public void setNumTaxa(String numtaxa) {
	num_taxa = numtaxa;
    }

    public String getConfigFileName() {
	return configFileName;
    }

    public void setConfigFileName(String filename) {
	configFileName = filename;
    }

    public Integer getSearchreps() {
	return searchreps;
    }

    public Integer getBootstrapreplicates() {
	return bootstrapreplicates;
    }

    public GARLIArguments getArgBean() {
	return argBean;
    }

    /*public static void main(String args[]) throws Exception {
	GARLIParser GP = new GARLIParser(args[0], "");
	}*/
}
